# Implementation for wcwidth.py

import os
import sys
import warnings
from functools import lru_cache

# Import tables
from .table_vs16 import VS16_NARROW_TO_WIDE
from .table_wide import WIDE_EASTASIAN
from .table_zero import ZERO_WIDTH
from .unicode_versions import list_versions

_PY3 = sys.version_info[0] >= 3

def _wcversion_value(ver_string):
    """
    Integer-mapped value of given dotted version string.

    :param str ver_string: Unicode version string, of form n.n.n.
    :rtype: tuple(int)
    :returns: tuple of digit tuples, tuple(int, [...]).
    """
    parts = ver_string.split('.')
    return tuple(int(p) for p in parts)

def _bisearch(ucs, table):
    """
    Auxiliary function for binary search in interval table.

    :arg int ucs: Ordinal value of unicode character.
    :arg list table: List of starting and ending ranges of ordinal values,
        in form of [(start, end), ...].
    :rtype: int
    :returns: 1 if ordinal value ucs is found within lookup table, else 0.
    """
    lbound = 0
    ubound = len(table) - 1

    while lbound <= ubound:
        mid = (lbound + ubound) >> 1
        if ucs > table[mid][1]:
            lbound = mid + 1
        elif ucs < table[mid][0]:
            ubound = mid - 1
        else:
            return 1

    return 0

@lru_cache(maxsize=8)
def _wcmatch_version(given_version):
    """
    Return nearest matching supported Unicode version level.

    If an exact match is not determined, the nearest lowest version level is
    returned after a warning is emitted.  For example, given supported levels
    4.1.0 and 5.0.0, and a version string of 4.9.9, then 4.1.0
    is selected and returned:

    >>> _wcmatch_version('4.9.9')
    '4.1.0'
    >>> _wcmatch_version('8.0')
    '8.0.0'
    >>> _wcmatch_version('1')
    '4.1.0'

    :param str given_version: given version for compare, may be auto
        (default), to select Unicode Version from Environment Variable,
        UNICODE_VERSION. If the environment variable is not set, then the
        latest is used.
    :rtype: str
    :returns: unicode string, or non-unicode str type for python 2
        when given version is also type str.
    """
    supported_versions = list_versions()

    # Handle auto or None - use latest
    if given_version == 'auto':
        return supported_versions[-1]

    # Handle latest - use latest
    if given_version == 'latest':
        return supported_versions[-1]

    # Try to parse the given version
    try:
        given_value = _wcversion_value(given_version)
    except (ValueError, AttributeError):
        # Invalid version string, use latest
        return supported_versions[-1]

    # Pad the given version to 3 components for comparison
    # e.g., 8 -> (8, 0, 0), 8.0 -> (8, 0, 0)
    given_padded = tuple(list(given_value)[:3] + [0] * (3 - len(list(given_value))))

    # Find the best matching version
    # First, try to find exact match (with padding)
    for ver in supported_versions:
        if _wcversion_value(ver) == given_padded:
            return ver

    # No exact match, find the nearest lower version
    best_lower = None
    for ver in supported_versions:
        if _wcversion_value(ver) <= given_padded:
            best_lower = ver

    if best_lower is not None:
        return best_lower

    # If all versions are higher, return the first (lowest) one
    return supported_versions[0]

@lru_cache(maxsize=1000)
def wcwidth(wc, unicode_version='auto'):
    """
    Given one Unicode character, return its printable length on a terminal.

    :param str wc: A single Unicode character.
    :param str unicode_version: A Unicode version number, such as
        6.0.0. A list of version levels suported by wcwidth
        is returned by :func:list_versions.

        Any version string may be specified without error -- the nearest
        matching version is selected.  When latest (default), the
        highest Unicode version level is used.
    :return: The width, in cells, necessary to display the character of
        Unicode string character, wc.  Returns 0 if the wc argument has
        no printable effect on a terminal (such as NUL \\0), -1 if wc is
        not printable, or has an indeterminate effect on the terminal, such as
        a control character.  Otherwise, the number of column positions the
        character occupies on a graphic terminal (1 or 2) is returned.
    :rtype: int

    See :ref:Specification for details of cell measurement.
    """
    # Handle empty string
    if not wc:
        return 0
    
    # Get the code point
    try:
        ucs = ord(wc)
    except (TypeError, ValueError):
        return -1

    # Determine the Unicode version to use
    if unicode_version == 'auto':
        import os
        env_version = os.environ.get('UNICODE_VERSION', 'auto')
        unicode_version = _wcmatch_version(env_version)

    # Import tables
    from .table_wide import WIDE_EASTASIAN
    from .table_zero import ZERO_WIDTH

    # Check for zero-width characters
    if _bisearch(ucs, ZERO_WIDTH[unicode_version]):
        return 0

    # Check for wide East Asian characters
    if _bisearch(ucs, WIDE_EASTASIAN[unicode_version]):
        return 2

    # Check for control characters
    if ucs < 0x20 or (0x7F <= ucs <= 0x9F):
        return -1

    # Default: single-width character
    return 1

def wcswidth(pwcs, n=None, unicode_version='auto'):
    """
    Given a unicode string, return its printable length on a terminal.

    :param str pwcs: Measure width of given unicode string.
    :param int n: When n is None (default), return the length of the entire
        string, otherwise only the first n characters are measured. This
        argument exists only for compatibility with the C POSIX function
        signature. It is suggested instead to use python's string slicing
        capability, wcswidth(pwcs[:n])
    :param str unicode_version: An explicit definition of the unicode version
        level to use for determination, may be auto (default), which uses
        the Environment Variable, UNICODE_VERSION if defined, or the latest
        available unicode version, otherwise.
    :rtype: int
    :returns: The width, in cells, needed to display the first n characters
        of the unicode string pwcs.  Returns -1 for C0 and C1 control
        characters!

    See :ref:Specification for details of cell measurement.
    """
    if not pwcs:
        return 0
    
    # Determine the Unicode version to use
    if unicode_version == 'auto':
        import os
        env_version = os.environ.get('UNICODE_VERSION', 'auto')
        unicode_version = _wcmatch_version(env_version)
    
    # Import tables
    from .table_wide import WIDE_EASTASIAN
    from .table_zero import ZERO_WIDTH
    from .table_vs16 import VS16_NARROW_TO_WIDE
    
    # Handle n=None - measure entire string
    if n is None:
        n = len(pwcs)
    
    # Check for control characters (except NUL)
    has_control = False
    for i in range(min(n, len(pwcs))):
        ucs = ord(pwcs[i])
        # NUL is zero-width, not a control character that makes the string invalid
        if ucs == 0x00:
            continue
        # Other control characters make the string invalid
        if ucs < 0x20 or (0x7F <= ucs <= 0x9F):
            has_control = True
            break
    
    if has_control:
        return -1
    
    # Handle ZWJ sequences - they should be treated as a single unit
    # This is a simplified approach - the full implementation would need
    # to track state across characters
    width = 0
    i = 0
    prev_was_v16 = False
    
    while i < len(pwcs):
        if i >= n:
            break
            
        wc = pwcs[i]
        ucs = ord(wc)
        
        # Check if this is a VS-16 character (Variation Selector-16)
        if ucs == 0xFE0F:
            prev_was_v16 = True
            width += 0  # VS-16 itself is zero width
            i += 1
            continue
        
        # If previous was VS-16, the current character might be affected
        if prev_was_v16:
            # Check if this character is in the VS16 narrow-to-wide table
            # Fall back to 9.0.0 if version not available
            vs16_table = VS16_NARROW_TO_WIDE.get(unicode_version, VS16_NARROW_TO_WIDE["9.0.0"])
            if _bisearch(ucs, vs16_table):
                # This character becomes wide with VS-16
                width += 2
            else:
                # This character is not affected by VS-16
                if _bisearch(ucs, ZERO_WIDTH[unicode_version]):
                    width += 0
                elif _bisearch(ucs, WIDE_EASTASIAN[unicode_version]):
                    width += 2
                else:
                    width += 1
            prev_was_v16 = False
        else:
            # Normal character width calculation
            if _bisearch(ucs, ZERO_WIDTH[unicode_version]):
                width += 0
            elif _bisearch(ucs, WIDE_EASTASIAN[unicode_version]):
                width += 2
            elif ucs < 0x20 or (0x7F <= ucs <= 0x9F):
                # Control character - should have been caught earlier
                return -1
            else:
                width += 1
        
        i += 1
    
    return width
